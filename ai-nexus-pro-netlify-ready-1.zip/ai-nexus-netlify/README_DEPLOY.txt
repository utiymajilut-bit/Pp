AI NEXUS PRO — NETLIFY DEPLOYMENT

1. Upload folder ini ke Netlify (Drag & Drop).
2. Setelah site dibuat, buka:
   Project configuration → Environment variables
3. Tambahkan variable:
   Name: XKIRO_API_KEY
   Value: API KEY xKiro kamu
   Pastikan scope Functions tersedia.
4. Trigger deploy baru setelah variable ditambahkan/diubah.
5. Buka URL Netlify dan coba Chat AI.

PENTING:
- Jangan memasukkan API key ke index.html.
- Jangan mengunggah file .env yang berisi API key.
- API key sekarang hanya dibaca oleh Netlify Function.
- Jika API key pernah dipublikasikan di HTML lama, sebaiknya revoke/regenerate key tersebut di xKiro.

STRUKTUR:
index.html
netlify.toml
netlify/functions/xkiro.mjs
README_DEPLOY.txt
